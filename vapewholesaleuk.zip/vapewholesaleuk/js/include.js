document.addEventListener("DOMContentLoaded", function () {
    // Load header
    fetch('/includes/header.html')
        .then(response => {
            if (!response.ok) throw new Error(`Header load failed: ${response.status}`);
            return response.text();
        })
        .then(data => {
            document.getElementById('header-placeholder').innerHTML = data;
        })
        .catch(err => console.error(err));

    // Load footer
    fetch('/includes/footer.html')
        .then(response => {
            if (!response.ok) throw new Error(`Footer load failed: ${response.status}`);
            return response.text();
        })
        .then(data => {
            document.getElementById('footer-placeholder').innerHTML = data;
        })
        .catch(err => console.error(err));
});
